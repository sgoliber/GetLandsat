
Purpose
=======

This is a users manual and collection of example notebooks for the hubzero (https://hubzero.org/) and nanoHUB (https://nanohub.org/) science gateways.

Some of the notebooks and materials in the manual require certain notebooks extensions, otherwise they should work with most jupyter notebook servers.
