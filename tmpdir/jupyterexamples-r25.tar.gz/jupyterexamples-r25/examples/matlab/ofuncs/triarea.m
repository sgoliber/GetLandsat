function a = triarea(b, h)
a = 0.5 * (b.* h);

